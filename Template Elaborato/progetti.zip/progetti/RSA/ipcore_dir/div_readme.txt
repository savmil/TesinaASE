The following files were generated for 'div' in directory
/media/sf_ASE/VHDL/Milo/RSA/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * div.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * div.ngc
   * div.vhd
   * div.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * div.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * div.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * div.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * div_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * div.gise
   * div.xise

ISE file generator:
   Add description here...

   * div_flist.txt

Deliver Readme:
   Readme file for the IP.

   * div_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * div_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

